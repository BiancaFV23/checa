-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-04-2024 a las 12:44:59
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prenomina`
--
CREATE DATABASE IF NOT EXISTS `prenomina` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `prenomina`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prenomina`
--
-- Creación: 04-04-2024 a las 11:08:15
--

CREATE TABLE `prenomina` (
  `numeroemple` int(10) NOT NULL,
  `fechapre` varchar(20) NOT NULL,
  `horastrabajadas` varchar(20) NOT NULL,
  `horasextras` varchar(20) NOT NULL,
  `retardos` varchar(20) NOT NULL,
  `faltas` varchar(20) NOT NULL,
  `faltasjustificadas` varchar(20) NOT NULL,
  `pretotal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `prenomina`
--

INSERT INTO `prenomina` (`numeroemple`, `fechapre`, `horastrabajadas`, `horasextras`, `retardos`, `faltas`, `faltasjustificadas`, `pretotal`) VALUES
(96777907, '04/04/2024', '8', '0', '0', '0', '1', '0');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
