-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-04-2024 a las 12:43:06
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empleados`
--
CREATE DATABASE IF NOT EXISTS `empleados` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `empleados`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `checador`
--
-- Creación: 04-04-2024 a las 11:06:20
--

CREATE TABLE `checador` (
  `id_checador` int(20) NOT NULL,
  `numempleado` varchar(20) NOT NULL,
  `entrada` varchar(20) NOT NULL,
  `salida` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--
-- Creación: 04-04-2024 a las 11:07:12
-- Última actualización: 05-04-2024 a las 02:53:50
--

CREATE TABLE `usuarios` (
  `id_empleado` int(20) NOT NULL,
  `numempleado` varchar(20) NOT NULL,
  `apellidopa` varchar(20) NOT NULL,
  `apellidoma` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `fechanacimiento` varchar(20) NOT NULL,
  `area` varchar(20) NOT NULL,
  `puesto` varchar(20) NOT NULL,
  `fechaingreso` varchar(20) NOT NULL,
  `contra` varchar(20) NOT NULL,
  `contrase` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_empleado`, `numempleado`, `apellidopa`, `apellidoma`, `nombre`, `fechanacimiento`, `area`, `puesto`, `fechaingreso`, `contra`, `contrase`) VALUES
(1, '96777907', 'Figueroa', 'Valle', 'Bianca', '23/04/1997', 'ropa', 'asesor', '15/06/2015', '123', '123'),
(2, '92101501', 'Del real', 'Lopez', 'Martha Ofelia', '20/11/1980', 'ropa', 'gerente', '10/09/2010', '12345', '12345'),
(3, '96777908', 'Chavez', 'Espinoza', 'Isabel', '15/08/1996', 'ropa', 'asesor', '15/07/2016', '12345', '12345'),
(4, '92101502', 'Fierro', 'Botello', 'Wendy', '07/06/1996', 'ropa', 'asesor', '12/10/2020', '1234567', '1234567');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `checador`
--
ALTER TABLE `checador`
  ADD PRIMARY KEY (`id_checador`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_empleado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `checador`
--
ALTER TABLE `checador`
  MODIFY `id_checador` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_empleado` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
